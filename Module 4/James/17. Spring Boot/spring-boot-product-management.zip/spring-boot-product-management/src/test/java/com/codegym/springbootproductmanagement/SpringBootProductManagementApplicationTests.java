package com.codegym.springbootproductmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProductManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
