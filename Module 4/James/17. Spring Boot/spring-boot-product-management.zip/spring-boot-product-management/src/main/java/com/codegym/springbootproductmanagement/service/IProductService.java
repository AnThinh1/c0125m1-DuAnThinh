package com.codegym.springbootproductmanagement.service;
import com.codegym.springbootproductmanagement.model.Product;
public interface IProductService extends IGenerateService<Product> {
}